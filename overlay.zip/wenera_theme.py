import re, sys, colorsys, pathlib

res = pathlib.Path(sys.argv[1])
main = res.parent
HEX = re.compile(r'#(?:[0-9a-fA-F]{8}|[0-9a-fA-F]{6})\b')

def conv(m):
    h = m.group(0)[1:]
    a = ''
    if len(h) == 8:
        a, h = h[:2], h[2:]
    r, g, b = [int(h[i:i+2], 16) / 255 for i in (0, 2, 4)]
    hh, l, s = colorsys.rgb_to_hls(r, g, b)
    hd = hh * 360
    if s > 0.25 and 70 <= hd <= 170 and l > 0.15:      # зелёный -> оранжевый
        r2, g2, b2 = colorsys.hls_to_rgb(24 / 360, min(max(l + 0.1, 0.5), 0.6), 0.95)
    elif s < 0.2 and l < 0.35:                          # тёмно-серый -> тёплый тёмный
        r2, g2, b2 = colorsys.hls_to_rgb(12 / 360, l * 0.9, 0.55)
    else:
        return m.group(0)
    return '#' + a + ''.join('%02X' % round(x * 255) for x in (r2, g2, b2))

NAME = re.compile(r'(<string\s+name="(?:app_name|app_short_name)"[^>]*>)[^<]*(</string>)')
xml_n = name_n = 0
for f in res.rglob('*.xml'):
    if f.name.startswith(('autumn_', 'wenera_', 'ic_launcher')):
        continue
    d = f.parent.name
    if not d.startswith(('values', 'drawable', 'layout', 'color')):
        continue
    t = f.read_text(encoding='utf-8')
    n = HEX.sub(conv, t)
    if d.startswith('values'):
        n2 = NAME.sub(r'\1Wenera Launcher\2', n)
        if n2 != n:
            name_n += 1
        n = n2
    if n != t:
        f.write_text(n, encoding='utf-8')
        xml_n += 1
print('xml changed:', xml_n, '| names changed:', name_n)

# горизонтальная ориентация главного экрана
man = main / 'AndroidManifest.xml'
if man.exists():
    t = man.read_text(encoding='utf-8')
    n = re.sub(r'(<activity\s+android:name="\.LauncherActivity")(?![^>]*screenOrientation)',
               r'\1 android:screenOrientation="sensorLandscape"', t)
    man.write_text(n, encoding='utf-8')
    print('manifest landscape:', n != t)

# зелёные картинки (кнопки и т.п.) -> оранжевые
try:
    from PIL import Image, ImageChops
    HLO, HHI, TARGET = 50, 120, 17          # оттенки в шкале 0..255
    png_n = 0
    for f in res.rglob('*.png'):
        if not f.parent.name.startswith('drawable'):
            continue
        try:
            im = Image.open(f).convert('RGBA')
            a = im.getchannel('A')
            h, s, v = im.convert('RGB').convert('HSV').split()
            mh = h.point(lambda x: 255 if HLO <= x <= HHI else 0)
            ms = s.point(lambda x: 255 if x > 64 else 0)
            mv = v.point(lambda x: 255 if x > 40 else 0)
            mask = ImageChops.darker(ImageChops.darker(mh, ms), mv)
            if mask.getbbox() is None:
                continue
            h2 = Image.composite(Image.new('L', h.size, TARGET), h, mask)
            out = Image.merge('HSV', (h2, s, v)).convert('RGB')
            out.putalpha(a)
            out.save(f)
            png_n += 1
        except Exception as e:
            print('skip', f.name, e)
    print('png recolored:', png_n)
except ImportError:
    print('Pillow not installed: png recolor skipped')
